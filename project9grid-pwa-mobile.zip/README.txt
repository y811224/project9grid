Project 9Grid PWA

這是一個可部署成手機網頁 App 的版本。

部署方式（最簡單）：
1. 解壓縮 ZIP。
2. 將整個資料夾拖曳到 Netlify Drop、Cloudflare Pages 或其他靜態網站空間。
3. 取得公開網址後，用 iPhone Safari 開啟。
4. 點 Safari 分享按鈕 → 加入主畫面。

注意：
- 本版資料儲存在使用者手機瀏覽器的 localStorage。
- 尚未加入帳號登入、雲端同步與多人共用。
